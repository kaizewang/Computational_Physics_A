由于上传不能超过30M，部分数据txt文件未上传。但作业基本要求的N=2,5,10数据均上传了。
没有上传的数据包括:
exp_(N=1000,M=1E4).txt
p_self_(x)(N=1000).txt
poisson_(N=10000,M=1E4).txt
self_(N=1000,M=1E4).txt